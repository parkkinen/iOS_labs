//
//  ViewController.swift
//  l3t1
//
//  Created by Kimmo Raappana on 10/09/2019.
//  Copyright © 2019 Kimmo Raappana. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

