//
//  ViewController.swift
//  l4t1
//
//  Created by Kimmo Raappana on 17/09/2019.
//  Copyright © 2019 Kimmo Raappana. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

    
    var player: AVAudioPlayer?

    @IBOutlet weak var image1: UIImageView!
    @IBOutlet weak var image2: UIImageView!
    
    @IBOutlet weak var image3: UIImageView!
    @IBOutlet weak var image4: UIImageView!
    
    @IBOutlet weak var segmentValue: UISegmentedControl!
    
    let mammalData = [("elephant.jpg", "elephant.wav"),
                      ("bear.jpg", "bear.wav"),
                      ("lamb.jpg", "lamb.wav"),
                      ("wolf.jpg", "wolf.wav")]

    let birdData = [("huuhkaja.jpg", "huuhkaja_norther_eagle_owl.mp3"),
                      ("peippo.jpg", "peippo_chaffinch.mp3"),
                      ("peukaloinen.jpg", "peukaloinen_wren.mp3"),
                      ("punatulkku.jpg", "punatulkku_northern_bullfinch.mp3")]
    
    lazy var imageArray = [image1, image2, image3, image4]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        ChangeMammals()
        
        
        let singleTap = UITapGestureRecognizer(target: self, action: #selector(tapDetected))
        singleTap.numberOfTapsRequired = 1
        image1.isUserInteractionEnabled = true
        image1.addGestureRecognizer(singleTap)
        
        let singleTap2 = UITapGestureRecognizer(target: self, action: #selector(tapDetected))
        singleTap2.numberOfTapsRequired = 1
        image2.isUserInteractionEnabled = true
        image2.addGestureRecognizer(singleTap2)
        
        let singleTap3 = UITapGestureRecognizer(target: self, action: #selector(tapDetected))
        singleTap3.numberOfTapsRequired = 1
        image3.isUserInteractionEnabled = true
        image3.addGestureRecognizer(singleTap3)
        
        let singleTap4 = UITapGestureRecognizer(target: self, action: #selector(tapDetected))
        singleTap4.numberOfTapsRequired = 1
        image4.isUserInteractionEnabled = true
        image4.addGestureRecognizer(singleTap4)
        
        

    }

    @IBAction func segmentChange(_ sender: Any) {
        if(segmentValue.selectedSegmentIndex == 0) {
            ChangeMammals()
        } else {
            ChangeBirds()
        }
        
    }
    
    @objc func tapDetected(sender: UITapGestureRecognizer) {
        if segmentValue.selectedSegmentIndex == 0{
            if(sender.view == image1){
                playSound(filename: "elephant")
            } else if (sender.view == image2) {
                playSound(filename: "bear")
            } else if (sender.view == image3) {
                playSound(filename: "lamb")
            } else {
                playSound(filename: "wolf")
            }
        } else {
            if(sender.view == image1){
                playSound(filename: "huuhkaja_norther_eagle_owl")
            } else if (sender.view == image2) {
                playSound(filename: "peippo_chaffinch")
            } else if (sender.view == image3) {
                playSound(filename: "peukaloinen_wren")
            } else {
                playSound(filename: "punatulkku_northern_bullfinch")
            }
        }
    }
    
    func playSound(filename: String) {
        
        var fileExtension = ""
        
        if(segmentValue.selectedSegmentIndex == 0) {
            fileExtension = "wav"
        } else {
            fileExtension = "mp3"
        }
        
        guard let url = Bundle.main.url(forResource: filename, withExtension: fileExtension) else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            
            /* The following line is required for the player to work on iOS 11. Change the file type accordingly*/
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
            
            /* iOS 10 and earlier require the following line:
             player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileTypeMPEGLayer3) */
            
            guard let player = player else { return }
            
            player.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    func ChangeMammals() {
        //change pics to mammals

        for (index, mammalImage) in imageArray.enumerated() {
            print(mammalData[index].0)
            imageArray[index]?.image = UIImage(named: mammalData[index].0)
        }
        

    }
    
    func ChangeBirds() {
        //change pics
        for (index, birdImage) in imageArray.enumerated() {
            print(birdData[index].0)
            imageArray[index]?.image = UIImage(named: birdData[index].0)
        }
    }
    
}

