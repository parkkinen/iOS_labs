//
//  ViewController.swift
//  l3t2
//
//  Created by Kimmo Raappana on 10/09/2019.
//  Copyright © 2019 Kimmo Raappana. All rights reserved.
//

import UIKit



class ViewController: UIViewController {

    @IBOutlet weak var browserTextField: UITextField!
    
    
    @IBOutlet weak var emailTextField: UITextField!
    
    @IBOutlet weak var callTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func openBrowser(_ sender: Any) {
        let url = NSURL(string: browserTextField.text!)!
        UIApplication.shared.openURL(url as URL)
    }
    
    @IBAction func sendEmail(_ sender: Any) {
        let emailString = emailTextField.text!
        let url = NSURL(string: "mailto:" + emailString)
        UIApplication.shared.openURL(url as! URL)
    }
    
    @IBAction func openCamera(_ sender: Any) {
        let cameraVc = UIImagePickerController()
        cameraVc.sourceType = UIImagePickerController.SourceType.camera
        self.present(cameraVc, animated: true, completion: nil)
        
    }
    
    @IBAction func createCall(_ sender: Any) {
        if let url = URL(string: "tel://\(callTextField.text!)") {
            UIApplication.shared.openURL(url)
        }
    }
    
}

