//
//  ViewController.swift
//  l4t2
//
//  Created by Kimmo Raappana on 17/09/2019.
//  Copyright © 2019 Kimmo Raappana. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var textValue: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func greet(_ sender: Any) {
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let greetHelloAnton = segue.destination as! GreetingViewViewController
        greetHelloAnton.textGreet2 = textValue.text!
    }
    
}

