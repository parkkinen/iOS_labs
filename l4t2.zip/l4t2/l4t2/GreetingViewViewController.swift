//
//  GreetingViewViewController.swift
//  l4t2
//
//  Created by Kimmo Raappana on 17/09/2019.
//  Copyright © 2019 Kimmo Raappana. All rights reserved.
//

import UIKit

class GreetingViewViewController: UIViewController {
    
    var textGreet2:String = ""

    @IBOutlet weak var DannyDeVito: UIImageView!
    @IBOutlet weak var LabelHello: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        LabelHello.text = textGreet2
        if(textGreet2 == "veikko"){
            DannyDeVito.image = UIImage(named: "danny.jpg")
        }
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
